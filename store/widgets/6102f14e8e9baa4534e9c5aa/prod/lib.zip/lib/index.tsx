/**
 * 注意！！
 * lib文件夹下的文件即是所有最终打包的文件，请勿将组件相关逻辑	写在lib之外的目录
 * 你可以这样规划你的组件
 * lib
 * --src
 * --utils
 */

import widget_1 from "./widget"
import "./index.scss"

export default widget_1
