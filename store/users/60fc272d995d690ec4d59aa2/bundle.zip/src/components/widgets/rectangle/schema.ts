import { WidgetProps } from "visible-editor";

export interface RectangleProps extends WidgetProps {
  config: {
    backgroundColor: string
  }
}