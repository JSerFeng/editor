import widgets from "."

window.widgetsCenter.use(widgets)

export default widgets
