import { memo, FC } from "react"
import {
	Route
} from "react-router-dom"

import text from "./widgets/text";
import rectangle from "./widgets/rectangle";

const { FC: Text } = text;
const { FC: Rectangle } = rectangle;

const RenderMain: FC = () => {
  return (
    <div className="render-main" style={{
      position: "relative",
      width: "1024px",
      height: "768px",
    }}>
      
<Route path="/" exact={ true }>
	<div
		style={{
			position: "absolute",
			width: "87px",
			height: "77.5px",
			left: "425px",
			top: "229px"
		}}
	>
		<Text 
			config={{
  "fontSize": 16,
  "color": "black",
  "padding": 15,
  "content": "文本框",
  "justifyContent": "center",
  "alignItems": "center",
  "backgroundColor": "#fff"
}}
			pos={{
  "x": 425,
  "y": 229,
  "w": 87,
  "h": 77.5
}}
			style={{}}
			/>
	</div>
</Route>

<Route path="/" exact={ true }>
	<div
		style={{
			position: "absolute",
			width: "200px",
			height: "155px",
			left: "512px",
			top: "229px"
		}}
	>
		<Rectangle 
			config={{
  "backgroundColor": "rgba(25, 11, 110, 1)",
  "opacity": "1",
  "bgImage": "",
  "bgSize": "auto",
  "borders": [
    {
      "name": "左上",
      "border": "borderTopLeftRadius",
      "value": "0"
    },
    {
      "name": "右上",
      "border": "borderTopRightRadius",
      "value": "0"
    },
    {
      "name": "右下",
      "border": "borderBottomRightRadius",
      "value": "0"
    },
    {
      "name": "右下",
      "border": "borderBottomLeftRadius",
      "value": "0"
    }
  ]
}}
			pos={{
  "x": 512,
  "y": 229,
  "w": 200,
  "h": 155
}}
			style={{}}
			/>
	</div>
</Route>

<Route path="/" exact={ true }>
	<div
		style={{
			position: "absolute",
			width: "247px",
			height: "100px",
			left: "312px",
			top: "584px"
		}}
	>
		<Rectangle 
			config={{
  "backgroundColor": "rgb(164, 151, 230)",
  "opacity": "1",
  "bgImage": "",
  "bgSize": "auto",
  "borders": [
    {
      "name": "左上",
      "border": "borderTopLeftRadius",
      "value": "0"
    },
    {
      "name": "右上",
      "border": "borderTopRightRadius",
      "value": "0"
    },
    {
      "name": "右下",
      "border": "borderBottomRightRadius",
      "value": "0"
    },
    {
      "name": "右下",
      "border": "borderBottomLeftRadius",
      "value": "0"
    }
  ]
}}
			pos={{
  "x": 312,
  "y": 584,
  "w": 247,
  "h": 100
}}
			style={{}}
			/>
	</div>
</Route>
    </div>
  )
}

export default memo(RenderMain)
