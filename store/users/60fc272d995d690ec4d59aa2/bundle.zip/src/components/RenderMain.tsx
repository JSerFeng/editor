import { memo, FC } from "react"
import {
	Route
} from "react-router-dom"

import custom-widget-1 from "./widgets/custom-widget-1";

const { FC: Custom-widget-1 } = custom-widget-1;

const RenderMain: FC = () => {
  return (
    <div className="render-main" style={{
      position: "relative",
      width: "1024px",
      height: "768px",
    }}>
      <Route path="/" exact={ true }>
	<div
		style={{
			position: "absolute",
			width: "200px",
			height: "200px",
			left: "412px",
			top: "284px"
		}}
	>
		<Custom-widget-1 
			config={{
  "customColor": "blue",
  "title": "我是标题",
  "content": "我是内容"
}}
			pos={{
  "x": 412,
  "y": 284,
  "w": 200,
  "h": 200
}}
			style={{}}
			/>
	</div>
</Route>
    </div>
  )
}

export default memo(RenderMain)
